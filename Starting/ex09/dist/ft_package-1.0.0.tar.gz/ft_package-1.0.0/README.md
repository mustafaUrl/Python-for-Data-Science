# Example Package

This is a simple example package. You can use
[GitHub-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.


count_in_list(x)

    Return the number of occurrences of x in the array.
