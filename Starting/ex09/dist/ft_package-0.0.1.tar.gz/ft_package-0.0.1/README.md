# count_in_list(x)

    Return the number of occurrences of x in the array.
