def count_in_list(lst, str_):
    return lst.count(str_)

